package com.aimdek.crudDemo.service;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.aimdek.crudDemo.utility.SingletonResult;

@WebServlet("/delete")
public class DeleteData extends HttpServlet {
	
	Connection cn = SingletonResult.getConnection();
	
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
	{
		try
		{
			int stud_id = Integer.parseInt(req.getParameter("id"));
			
			PreparedStatement prstmt = cn.prepareStatement("delete from resulttb where id = ?");
			prstmt.setInt(1, stud_id);
			
			prstmt.executeUpdate();
			
			res.sendRedirect("Success.jsp");
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			res.sendRedirect("Error.jsp");
		}
	}

	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
	{
		doGet(req, res);
	}
}