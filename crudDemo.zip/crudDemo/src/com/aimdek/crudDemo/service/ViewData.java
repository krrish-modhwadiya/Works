package com.aimdek.crudDemo.service;

import java.io.IOException;
import java.sql.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.aimdek.crudDemo.model.Student;
import com.aimdek.crudDemo.utility.SingletonResult;

@WebServlet("/view")
public class ViewData extends HttpServlet
{
   Connection cn = SingletonResult.getConnection();
	
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
	{
		int id = Integer.parseInt(req.getParameter("id"));
		
		try
		{
			Statement st = cn.createStatement();
			ResultSet rs = st.executeQuery("select * from resulttb where id = "+id);
			
			if(rs.next() != false)
			{
				int stud_id = rs.getInt("id");
				String stud_name = rs.getString("name");
				int stud_marks = rs.getInt("marks");
				
				Student stud = new Student(stud_id, stud_name, stud_marks);
				req.setAttribute("student", stud);
				RequestDispatcher dis = req.getRequestDispatcher("result.jsp");
				dis.forward(req, res);
			}
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}
	
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
	{
		doGet(req, res);
	}
}