package com.aimdek.crudDemo.service;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.aimdek.crudDemo.utility.SingletonResult;

@WebServlet("/insert")
public class InsertData extends HttpServlet
{
	
	Connection cn = SingletonResult.getConnection();
	
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
	{		
		try {
			
			int stud_id = Integer.parseInt(req.getParameter("id"));
			String stud_name = req.getParameter("name");
			int stud_marks = Integer.parseInt(req.getParameter("marks"));
			
			PreparedStatement prstmt = cn.prepareStatement("insert into resulttb values (?,?,?)");
			prstmt.setInt(1, stud_id);
			prstmt.setString(2, stud_name);
			prstmt.setInt(3, stud_marks);
			
			prstmt.executeUpdate();
			
			res.sendRedirect("Success.jsp");
			
		} catch (SQLException e) {
			System.out.println(e.getMessage());
			res.sendRedirect("Error.jsp");
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		doGet(request, response);
	}
}