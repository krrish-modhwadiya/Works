package com.aimdek.crudDemo.utility;

import java.sql.Connection;
import java.sql.DriverManager;

public class SingletonResult
{
	private static SingletonResult sgcn;
	private static String url = "jdbc:mysql://localhost:3306/resultdb";
	private static String username = "root";
    private static String password = "rootroot8";
    
    private SingletonResult() {}
    
    public static Connection getConnection() 
    {
    	try
    	{
    		Class.forName("com.mysql.jdbc.Driver");
    		return DriverManager.getConnection(url, username, password);
    	}
    	catch(Exception sqe)
    	{
    		throw new RuntimeException("Error connecting to the database", sqe);
    	}
    }
}