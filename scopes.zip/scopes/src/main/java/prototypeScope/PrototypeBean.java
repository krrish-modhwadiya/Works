package prototypeScope;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import singletonScope.SingleMessage;

public class PrototypeBean {
	
	public static void main(String args[]) {
		ApplicationContext ac = new ClassPathXmlApplicationContext("Bean_Scope.xml");
		
		PrototypeMessage pm1 = ac.getBean("pro_message", PrototypeMessage.class);
		PrototypeMessage pm2 = ac.getBean("pro_message", PrototypeMessage.class);

		pm1.setMsg("name1");
		pm2.setMsg("name2");
		
		pm1.printMessage();
		pm2.printMessage();
	}
}