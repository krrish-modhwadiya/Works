package prototypeScope;

public class PrototypeMessage {
	
	private String msg;

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}
	
	public void printMessage() {
		System.out.println(msg);
	}
}
