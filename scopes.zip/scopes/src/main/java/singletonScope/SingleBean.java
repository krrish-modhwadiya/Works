package singletonScope;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SingleBean {
	
	public static void main(String args[]) {
		ApplicationContext ac = new ClassPathXmlApplicationContext("Bean_Scope.xml");
		
		SingleMessage sm1 = ac.getBean("message", SingleMessage.class);
		SingleMessage sm2 = ac.getBean("message", SingleMessage.class);
		
		sm1.setMsg("name1");
		sm2.setMsg("name2");
		
		sm1.printMessage();
		sm2.printMessage();
	}
}