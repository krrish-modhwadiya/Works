package com.aimdek.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.aimdek.dao.EmployeeDao;
import com.aimdek.model.Employee;

@Controller
public class MainController {

	@Autowired
	private EmployeeDao dao;
	
	@RequestMapping(value = "/")
	public ModelAndView listEmployee(ModelAndView model) {
		List<Employee> listEmployee = dao.list();
		model.addObject("listEmployee", listEmployee);
		model.setViewName("index");
		return model; 
	}
	
	@RequestMapping(value = "/new", method = RequestMethod.GET	)
	public ModelAndView newEmployee(ModelAndView model) {
		Employee employee = new Employee();
		model.addObject("employee", employee);
		model.setViewName("employee_form");
		return model;
	}
	
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public ModelAndView saveEmployee(@ModelAttribute Employee employee) {
		if(employee.getEmpId() == null) {
			dao.save(employee);
		}else {
			dao.update(employee);
		}
		return new ModelAndView("redirect:/");
	}
	
	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public ModelAndView editEmployee(HttpServletRequest req) {
		Integer id = Integer.parseInt(req.getParameter("id"));
		Employee emp = dao.get(id);
		
		ModelAndView model = new ModelAndView("employee_form");
		model.addObject("employee", emp );
		
		return model;
	}
	
	@RequestMapping(value = "/delete", method = RequestMethod.GET)
	public ModelAndView delete(@RequestParam Integer id) {
		dao.delete(id);
		
		return new ModelAndView("redirect:/");
	}
}