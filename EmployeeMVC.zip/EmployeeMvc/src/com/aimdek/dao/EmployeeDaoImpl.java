package com.aimdek.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;

import com.aimdek.model.Employee;

public class EmployeeDaoImpl implements EmployeeDao {

	private JdbcTemplate jdbc;

	public EmployeeDaoImpl(DataSource dataSource) {
        jdbc = new JdbcTemplate(dataSource);
    }

	@Override
	public void saveOrUpdate(Employee emp) {
	    if (emp.getEmpId() > 0) {
	        String sql = "UPDATE employee SET emp_name=?, salary=? WHERE emp_Id=?";
	        jdbc.update(sql, emp.getEmpName(), emp.getSalary(), emp.getEmpId());
	    } else {
	        String sql = "INSERT INTO employee (emp_name, salary)" + " VALUES (?, ?)";
	        jdbc.update(sql, emp.getEmpName(), emp.getSalary());
	    }
	}
	
	@Override
	public int save(Employee emp) {
		String query = "insert into employee(emp_name, salary) values(?,?)";
		return jdbc.update(query, emp.getEmpName(), emp.getSalary());
	}

	@Override
	public Integer update(Employee emp) {
		String query = "update employee set emp_name = ?, salary = ? where emp_Id = ?";
		return jdbc.update(query, emp.getEmpName(), emp.getSalary(), emp.getEmpId());
	}

	@Override
	public int delete(Integer id) {
		String query = "delete from employee where emp_Id = ?";
		return jdbc.update(query, id);
	}

	@Override
	public Employee get(Integer id) {
		String query = "SELECT * FROM employee WHERE emp_Id=" + id;
	    return jdbc.query(query, new ResultSetExtractor<Employee>() {
	 
	        @Override
	        public Employee extractData(ResultSet rs) throws SQLException,
	                DataAccessException {
	            if (rs.next()) {
	                Employee emp = new Employee();
	                emp.setEmpId(rs.getInt("emp_Id"));
	                emp.setEmpName(rs.getString("emp_name"));
	                emp.setSalary(rs.getInt("salary"));
	                return emp;
	            }
	            return null;
	        }
	    });
	}

	@Override
	public List<Employee> list() {
		String query = "select * from employee";
		
		RowMapper<Employee> rwm = new RowMapper<Employee>() {

			@Override
			public Employee mapRow(ResultSet rs, int rowNum) throws SQLException {
				Integer id = rs.getInt("emp_Id");
				String name = rs.getString("emp_name");
				int salary = rs.getInt("salary");
				return new Employee(id, name, salary);
			}
		};
		return jdbc.query(query, rwm);
	}
}