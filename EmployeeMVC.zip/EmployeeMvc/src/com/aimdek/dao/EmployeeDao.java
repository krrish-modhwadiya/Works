package com.aimdek.dao;

import java.util.List;

import com.aimdek.model.Employee;

public interface EmployeeDao {

	public int save(Employee emp);
	
	public Integer update(Employee emp);
	
	public int delete(Integer id);
	
	public Employee get(Integer id);
	
	public List<Employee> list();
}